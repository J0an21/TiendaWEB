

UPDATE productos
SET existencias = 100
WHERE existencias = 10;
