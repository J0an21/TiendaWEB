/* 2025-05-06 10:27:36 [21 ms] */ 
INSERT INTO categorias (codigo, descripcion) VALUES
(1, 'Aventura'),
(2, 'Deportes'),
(3, 'Estrategia'),
(4, 'Puzzles');
/* 2025-05-06 10:28:10 [27 ms] */ 
INSERT INTO productos (codigo, descripcion, precio, existencias, imagen, categoria) VALUES
(1, 'Fifa 08', 15.00, 10, 'imagenes/fifa8.jpg', 1),
(2, 'Fifa 09', 15.00, 10, 'imagenes/fifa9.jpg', 1),
(3, 'Fifa 10', 15.00, 10, 'imagenes/fifa10.jpg', 1),
(4, 'Inazuma Eleven', 20.00, 10, 'imagenes/ie.jpg', 1),
(5, 'Inazuma Eleven 2: Ventisca Eterna', 30.00, 10, 'imagenes/ie2v.jpg', 1),
(6, 'Inazuma Eleven 2: Tormenta de Fuego', 30.00, 10, 'imagenes/ie2t.jpg', 1),
(7, 'Mario y Luigi', 25.00, 10, 'imagenes/mario_luigi.jpg', 1),
(8, 'Mario Kart', 20.00, 10, 'imagenes/mario_kart.jpg', 1),
(9, 'Mario Party DS', 25.00, 10, 'imagenes/mario_party.jpg', 1),
(10, 'Super Mario Bros', 20.00, 10, 'imagenes/mario_1.jpg', 1),
(11, 'Sonic Rush Adventure', 20.00, 10, 'imagenes/sonic_ad.jpg', 1),
(12, 'Sonic Colours', 25.00, 10, 'imagenes/sonic_col.jpg', 1),
(13, 'Sonic Chronicles', 30.00, 10, 'imagenes/sonic_chro.jpg', 1),
(14, 'Profesor Layton y la Caja de Pandora', 45.00, 10, 'imagenes/pfl_lcp.jpg', 1),
(15, 'Profesor Layton y el Futuro Perdido', 45.00, 10, 'imagenes/pfl_atuf.jpg', 1),
(16, 'Profesor Layton y la Llamada del Espector', 45.00, 10, 'imagenes/pfl_llde.jpg', 1),
(17, 'Pokemon Platino', 40.00, 10, 'imagenes/pokemon_pla.jpg', 1),
(18, 'Pokemon Diamante', 35.00, 10, 'imagenes/pokemon_dia.jpg', 1),
(19, 'Pokemon Perla', 35.00, 10, 'imagenes/pokemon_pearl.jpg', 1),
(20, 'Pokemon HeartGold', 40.00, 10, 'imagenes/pokemon_hg.jpg', 1),
(21, 'Pokemon SoulSilver', 40.00, 10, 'imagenes/pokemon_ss.jpg', 1);
/* 2025-05-06 10:29:01 [16 ms] */ 
UPDATE productos
SET existencias = 100
WHERE existencias = 10;
/* 2025-05-07 09:57:19 [27 ms] */ 
SELECT codigo, descripcion, precio, existencias, imagen, categoria FROM productos WHERE categoria = 1 LIMIT 100;
