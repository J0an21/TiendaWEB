ALTER TABLE `pedidos` 
	CHANGE `estado` `estado` int(11) NOT NULL ;