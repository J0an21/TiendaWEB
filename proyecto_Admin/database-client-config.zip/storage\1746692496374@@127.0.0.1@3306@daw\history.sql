/* 2025-05-08 10:30:15 [78 ms] */ 
CREATE TABLE usuarios(
	codigo INTEGER NOT NULL AUTO_INCREMENT,
	usuario VARCHAR(32) NOT NULL UNIQUE,
	clave VARCHAR(40) DEFAULT '',
	activo INTEGER DEFAULT 1,
	admin INTEGER DEFAULT 0,
	nombre VARCHAR(64) DEFAULT NULL,
	apellidos VARCHAR(128) DEFAULT NULL,
	domicilio VARCHAR(128) DEFAULT NULL,
	poblacion VARCHAR(64) DEFAULT NULL,
	provincia VARCHAR(32) DEFAULT NULL,
	cp CHAR(5) DEFAULT NULL,
	telefono CHAR(9) DEFAULT NULL,
	PRIMARY KEY(codigo));

CREATE TABLE categorias(
	codigo INTEGER NOT NULL AUTO_INCREMENT,
	descripcion VARCHAR(255) DEFAULT NULL,
	PRIMARY KEY(codigo)
);
/* 2025-05-08 10:30:42 [49 ms] */ 
CREATE TABLE productos(
	codigo INTEGER NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(255) DEFAULT NULL,
	precio DECIMAL(8,2) DEFAULT 0,
	existencias INTEGER DEFAULT 0,
	imagen VARCHAR(255) DEFAULT NULL,
	categoria INTEGER NOT NULL,
	PRIMARY KEY(codigo),
	FOREIGN KEY pertenecea(categoria) REFERENCES categorias(codigo)
);
/* 2025-05-08 10:30:50 [36 ms] */ 
CREATE TABLE estados(
	codigo INTEGER NOT NULL AUTO_INCREMENT,
	descripcion VARCHAR(16) DEFAULT NULL,
	PRIMARY KEY(codigo)
);
/* 2025-05-08 10:31:01 [54 ms] */ 
CREATE TABLE pedidos(
	codigo INTEGER NOT NULL AUTO_INCREMENT,
	persona INTEGER NOT NULL,
	fecha DATE DEFAULT(CURRENT_DATE),
	importe DECIMAL(8,2) DEFAULT 0,
	estado INTEGER NOT NULL,
	PRIMARY KEY(codigo),
	FOREIGN KEY pedidopor(persona) REFERENCES usuarios(codigo),
	FOREIGN KEY enestado(estado) REFERENCES estados(codigo)
);
/* 2025-05-08 10:31:06 [40 ms] */ 
CREATE TABLE detalle(
	codigo_pedido INTEGER NOT NULL,
	codigo_producto INTEGER NOT NULL,
	unidades INTEGER DEFAULT 1,
	precio_unitario DECIMAL(8,2) DEFAULT 0,
	PRIMARY KEY(codigo_pedido,codigo_producto),
	FOREIGN KEY referentea(codigo_pedido) REFERENCES pedidos(codigo),
	FOREIGN KEY contiene(codigo_producto) REFERENCES productos(codigo)
);
/* 2025-05-08 10:32:20 [18 ms] */ 
INSERT INTO categorias (codigo, descripcion) VALUES
(1, 'Aventura'),
(2, 'Deportes'),
(3, 'Estrategia'),
(4, 'Puzzles');
/* 2025-05-08 10:33:22 [21 ms] */ 
INSERT INTO productos (codigo, nombre, precio, existencias, imagen, categoria) VALUES
(1, 'Fifa 08', 15.00, 100, 'imagenes/fifa8.jpg', 1),
(2, 'Fifa 09', 15.00, 0, 'imagenes/fifa9.jpg', 1),
(3, 'Fifa 10', 15.00, 100, 'imagenes/fifa10.jpg', 1),
(4, 'Inazuma Eleven', 20.00, 100, 'imagenes/ie.jpg', 1),
(5, 'Inazuma Eleven 2: Ventisca', 30.00, 0, 'imagenes/ie2v.jpg', 1),
(6, 'Inazuma Eleven 2: Tormenta', 30.00, 100, 'imagenes/ie2t.jpg', 1),
(7, 'Mario y Luigi', 25.00, 100, 'imagenes/mario_luigi.jpg', 1),
(8, 'Mario Kart', 20.00, 100, 'imagenes/mario_kart.jpg', 1),
(9, 'Mario Party DS', 25.00, 100, 'imagenes/mario_party.jpg', 1),
(10, 'Super Mario Bros', 20.00, 100, 'imagenes/mario_1.jpg', 1),
(11, 'Sonic Rush Adventure', 20.00, 100, 'imagenes/sonic_ad.jpg', 1),
(12, 'Sonic Colours', 25.00, 100, 'imagenes/sonic_col.jpg', 1),
(13, 'Sonic Chronicles', 30.00, 100, 'imagenes/sonic_chro.jpg', 1),
(14, 'Profesor Layton y la Caja de Pandora', 45.00, 100, 'imagenes/pfl_lcp.jpg', 1),
(15, 'Profesor Layton y el Futuro Perdido', 45.00, 100, 'imagenes/pfl_atuf.jpg', 1),
(16, 'Profesor Layton y la Llamada del Espectro', 45.00, 100, 'imagenes/pfl_llde.jpg', 1),
(17, 'Pokemon Platino', 40.00, 100, 'imagenes/pokemon_pla.jpg', 1),
(18, 'Pokemon Diamante', 35.00, 100, 'imagenes/pokemon_dia.jpg', 1),
(19, 'Pokemon Perla', 35.00, 100, 'imagenes/pokemon_pearl.jpg', 1),
(20, 'Pokemon HeartGold', 40.00, 100, 'imagenes/pokemon_hg.jpg', 1),
(21, 'Pokemon SoulSilver', 40.00, 100, 'imagenes/pokemon_ss.jpg', 1);
/* 2025-05-09 12:35:43 [10 ms] */ 
SELECT * FROM usuarios WHERE usuario = 'zarasanta' AND clave = 'calvo2' LIMIT 100;
/* 2025-05-13 19:49:27 [86 ms] */ 
ALTER TABLE usuarios
ADD COLUMN dni VARCHAR(9),
ADD COLUMN correo_electronico VARCHAR(255);
/* 2025-05-14 01:54:11 [2 ms] */ 
SELECT * FROM usuarios LIMIT 100;
/* 2025-05-14 08:55:14 [5 ms] */ 
SELECT * FROM usuarios LIMIT 100;
/* 2025-05-24 13:58:22 [1 ms] */ 
SELECT * FROM pedidos LIMIT 100;
/* 2025-05-25 11:15:25 [6 ms] */ 
SELECT * FROM pedidos LIMIT 100;
/* 2025-05-25 11:50:27 [14 ms] */ 
DELETE FROM `pedidos` WHERE `codigo`=4;
/* 2025-05-25 11:52:19 [2 ms] */ 
SELECT * FROM pedidos LIMIT 100;
/* 2025-05-25 21:54:43 [1 ms] */ 
SELECT * FROM usuarios LIMIT 100;
